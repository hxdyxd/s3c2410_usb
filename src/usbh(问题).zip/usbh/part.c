
#include "part.h"
#undef	PART_DEBUG
//#define    PART_DEBUG
#ifdef	PART_DEBUG
#define	PRINTF	s_UartPrint
#else
#define PRINTF
#endif
/*
void init_part (block_dev_desc_t * dev_desc)
{
	dev_desc->part_type = PART_TYPE_DOS;
}


*/
void init_part (block_dev_desc_t * dev_desc)
{
    if (test_part_dos(dev_desc) == 0) 
    {
        dev_desc->part_type = PART_TYPE_DOS;
        return;
    }
}


int get_partition_info (block_dev_desc_t *dev_desc, int part, disk_partition_t *info)
{
    switch (dev_desc->part_type) 
    {
    case PART_TYPE_DOS:
        if (get_partition_info_dos(dev_desc,part,info) == 0) 
        {
            PRINTF("## Valid DOS partition found ##\n");
            return (0);
        }
        break;
    default:
        break;
    }
    return (-1);
}


static void print_part_header (const char *type, block_dev_desc_t * dev_desc)
{
    PRINTF("\nPartition Map for ");
    switch (dev_desc->if_type) 
    {
        case IF_TYPE_IDE:  	PRINTF("IDE");
        break;
        case IF_TYPE_SCSI: 	PRINTF("SCSI");
        break;
        case IF_TYPE_ATAPI:	PRINTF("ATAPI");
        break;
        case IF_TYPE_USB:	PRINTF("USB");
        break;
        case IF_TYPE_DOC:	PRINTF("DOC");
        break;
        default: 		    PRINTF("UNKNOWN");
        break;
    }
    PRINTF(" device %d  --   Partition Type: %s\n\n",
    dev_desc->dev, type);
}


/*
 * reports device info to the user
 */
void dev_print (block_dev_desc_t *dev_desc)
{
    /* number of blocks if 512bytes block size */
    unsigned long lba512;
    if (dev_desc->type==DEV_TYPE_UNKNOWN) 
    {
        PRINTF("not available\n");
        return;
    }
    if (dev_desc->if_type==IF_TYPE_SCSI)  
    {
        PRINTF("(%d:%d) ", dev_desc->target,dev_desc->lun);
    }
    if (dev_desc->if_type==IF_TYPE_IDE) 
    {
        PRINTF("Model: %s Firm: %s Ser#: %s\n",
        dev_desc->vendor,
        dev_desc->revision,
        dev_desc->product);
    } 
    else 
    {
        PRINTF("Vendor: %s Prod.: %s Rev: %s\n",
        dev_desc->vendor,
        dev_desc->product,
        dev_desc->revision);
    }
    PRINTF("            Type: ");
    if (dev_desc->removable)
    PRINTF("Removable ");
    switch (dev_desc->type & 0x1F) 
    {
        case DEV_TYPE_HARDDISK: PRINTF ("Hard Disk");
        break;
        case DEV_TYPE_CDROM: 	PRINTF("CD ROM");
        break;
        case DEV_TYPE_OPDISK: 	PRINTF("Optical Device");
        break;
        case DEV_TYPE_TAPE: 		PRINTF("Tape");
        break;
        default:		PRINTF("# %02X #", dev_desc->type & 0x1F);
        break;
    }
    PRINTF ("\n");
    if ((dev_desc->lba * dev_desc->blksz)>0L) 
    {
        unsigned long mb, mb_quot, mb_rem, gb, gb_quot, gb_rem;
        unsigned long lba;
        lba = dev_desc->lba;
        lba512 = (lba * (dev_desc->blksz/512));
        mb = (10 * lba512) / 2048;	/* 2048 = (1024 * 1024) / 512 MB */
        /* round to 1 digit */
        mb_quot	= mb / 10;
        mb_rem	= mb - (10 * mb_quot);
        gb = mb / 1024;
        gb_quot	= gb / 10;
        gb_rem	= gb - (10 * gb_quot);
        PRINTF ("            Capacity: %ld.%ld MB = %ld.%ld GB (%ld x %ld)\n",
        mb_quot, mb_rem,
        gb_quot, gb_rem,
        (unsigned long)lba,
        dev_desc->blksz);
    } 
    else 
    {
        PRINTF("            Capacity: not available\n");
    }
}


void print_part (block_dev_desc_t * dev_desc)
{
    switch (dev_desc->part_type) 
    {
    case PART_TYPE_MAC:
        PRINTF("## Testing for valid MAC partition ##\n");
        return;
    case PART_TYPE_DOS:
        PRINTF("## Testing for valid DOS partition ##\n");
        return;
    case PART_TYPE_ISO:
        PRINTF("## Testing for valid ISO Boot partition ##\n");
        return;
    case PART_TYPE_AMIGA:
        PRINTF("## Testing for a valid Amiga partition ##\n");
        return;
    }
    PRINTF("## Unknown partition table\n");
}


